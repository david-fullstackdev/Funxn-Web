
export class AppConfig {

    // public static API_URL = 'http://api.funxn.tapestryd.com/api';

    public static API_URL = 'http://localhost:3000/api';

    constructor() { }

}


